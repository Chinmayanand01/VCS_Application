package com.usecase.virtualcardsys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VirtualcardsysApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtualcardsysApplication.class, args);
	}

}
