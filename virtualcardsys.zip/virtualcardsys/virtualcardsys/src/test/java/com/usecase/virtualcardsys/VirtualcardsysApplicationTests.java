package com.usecase.virtualcardsys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtualcardsysApplicationTests {

	@Test
	void contextLoads() {
	}

}
